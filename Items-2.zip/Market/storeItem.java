import java.util.*;
public class storeItem
{
  private int inventory;
  private String name;
  private double price;
  private String description;
  private String FDAGrade;
  private int servingSize;
  private String brand;

  public storeItem (String myName, int myServingSize, int myInventory, double myPrice, String myDescription, String myFDAGrade, String myBrand)
  {
    name = myName;
    servingSize = myServingSize;
    inventory = myInventory;
    price = myPrice;
    description = myDescription;
    FDAGrade = myFDAGrade;
    brand = myBrand;
  }


  public void addInventory(int itemsAdded)
  {
    inventory += itemsAdded;
  }

  public void changePrice(double newPrice)
  {
    price = newPrice;
  }

  public void updateDescription(String newDescription)
  {
    description = newDescription;
  }

  public void updateServingSize(int newServingSize)
  {
    servingSize = newServingSize;
  }

  public double getPrice()
  {
    return price;
  }

  public String getName()
  {
    return name;
  }

  public int getInventory()
  {
    return inventory;
  }

  public String getDescription()
  {
    return description;
  }

  public String getFDAGrade()
  {
    return FDAGrade;
  }
  public int getServingSize()
  {
    return servingSize;
  }
}