import java.util.*;
public class groceryStore
{
  private String storeName;
  private ArrayList<storeItem> inventory = new ArrayList<storeItem>();
  private String address;

  public groceryStore(String myStoreName, String myAddress)
  {
    storeName = myStoreName;
    address = myAddress;
    ArrayList<storeItem> inventory = new ArrayList<storeItem>();
  }
  
  public void addStoreItem(ArrayList<storeItem> itemsToAdd)
  {
    for (int x = 0; x < itemsToAdd.size(); x++)
    {
      inventory.add(itemsToAdd.get(x));
    }
  }
  
  public void addStoreItem(storeItem itemToAdd)
  {
      inventory.add(itemToAdd);
    }

  public ArrayList<storeItem> findItem(String itemToFind) 
  {
    ArrayList<storeItem> results = new ArrayList<storeItem>();
    for (int x = 0; x < inventory.size(); x++)
    {
      if (inventory.get(x).getName().toLowerCase().indexOf(itemToFind)>=0)
      { 
        results.add(inventory.get(x));
      }
    }
    return results;
  }

}