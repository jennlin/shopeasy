import java.text.*;
public class shopperProfile
{
  private String name;
  private String timePickUp;
  private int tagNumber;
  private int shopperCode=0;
  private paymentCard card;
  private Basket cart;
  private int n=0;

  public shopperProfile (String myName, String myTimePickUp, paymentCard myCard)
  {
    name = myName;
    timePickUp = myTimePickUp;
    card = myCard;
  }
  private String generateNewItemCode()
  {
    int n = shopperCode;
    String pattern="00000000";
    DecimalFormat myFormatter = new DecimalFormat(pattern);
    String output = myFormatter.format(n);
    return output;
  }
 public Basket getBasket()
 {
   return cart;
 }

}

// has a credit card (int), shopping list (Array List),
// time pick up (String), tag number (int),
// client class
