import java.util.*;
public class shopper
{
  private String name;
  private String email;
  private String phoneNumber;
  private String username;
  private String password;
  private String address;
  private paymentCard card;
  private shopperProfile profile;
  private ArrayList<String> users;

  public shopper(String myName, String myEmail, String myPhoneNumber, String myUsername, String myPassword, String myAddress)
  {
    name = myName;
    email = myEmail;
    phoneNumber = myPhoneNumber;
    username = myUsername;
    password = myPassword;
  }
  public void newPurchase(String myTimePickUp)
  {
    profile = new shopperProfile(name, myTimePickUp, card);
  }

  public void newCard(String myPin, String myCardType, String mySecurityCode, String myExpirationDate)
  {
    card = new paymentCard(myPin, myCardType, mySecurityCode, myExpirationDate);
  }

  public void updateEmail(String newEmail)
  {
    email = newEmail;
  }
  public String updatePassword(String newPassword)
  {
    if (newPassword.equals(password))
    {
      return "Your new password cannot be the same as your old password.";
    }
    else
    {
      password = newPassword;
    }
    return "Successful.";
  }
  public void updateAddress(String newAddress)
  {
    address = newAddress;}
  public String getUsername()
  {
      return username;
    }
  public String getPassword()
  {
      return password;
    }
    public Basket getCart()
    {
        return profile.getBasket();
    }
}