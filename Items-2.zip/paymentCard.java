public class paymentCard
{
  private String pin;
  private String cardType;
  private String securityCode;
  private String expirationDate;

  public paymentCard(String myPin, String myCardType, String mySecurityCode, String myExpirationDate)
  {
    pin = myPin;
    cardType =  myCardType;
    securityCode = mySecurityCode;
    expirationDate = myExpirationDate;
  }
}