import java.util.*;
public class Basket
{
  private ArrayList<storeItem> basketCartItems = new ArrayList<storeItem>();
  private double totalCost = 0;

  public Basket()
  {
    totalCost = 0;
    ArrayList<storeItem> basketCartItems = new ArrayList<storeItem>();
  }

  public void addItem(storeItem itemToAdd)
  {
    if (itemToAdd.getInventory() >= 0)
    {
      basketCartItems.add(itemToAdd);
    }
  }

  public double calculateCost()
  {
    for (int i = 0; i<basketCartItems.size(); i++)
    {
      totalCost += basketCartItems.get(i).getPrice();
    }
    return totalCost;
  }

  public double getTotalCost()
  {
    return totalCost;
  }
  }
